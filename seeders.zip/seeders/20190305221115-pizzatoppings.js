'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    /*
      Add altering commands here.
      Return a promise to correctly handle asynchronicity.

      Example:
      return queryInterface.bulkInsert('People', [{
        name: 'John Doe',
        isBetaMember: false
      }], {});
    */
   return queryInterface.bulkInsert('pizzatoppings', [{
    IngredientId: 34,
    PizzaId: 21
  },
  {
    IngredientId: 35,
    PizzaId: 22
  },
  {
    IngredientId: 36,
    PizzaId: 22
  },
  {
    IngredientId: 40,
    PizzaId: 22
  },
  {
    IngredientId: 34,
    PizzaId: 23
  },
  {
    IngredientId: 41,
    PizzaId: 23
  }], {});
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.bulkDelete('pizzatoppings', null, {});
    /*
      Add reverting commands here.
      Return a promise to correctly handle asynchronicity.

      Example:
      return queryInterface.bulkDelete('People', null, {});
    */
  }
};
